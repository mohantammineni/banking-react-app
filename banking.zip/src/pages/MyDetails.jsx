import CountryRestriction from "./restriction/CountryRestriction";

const MyDetails = () =>{
   
    return (
        <CountryRestriction message="This feature is not supported in your region." />
     
    )
}

export default MyDetails;