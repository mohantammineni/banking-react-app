import React, { useEffect, useState } from "react";
import { Row, Col } from "antd";
import AccountSummary from "./AccountSummary";
import AccountBalance from "./AccountBalance";
import Approvals from "./Approvals";
import CurrencyConverter from "./CurrencyConverter";

const Dashboard = () => {
  const [userData, setUserData] = useState(null);

  useEffect(() => {
    // Fetch user data from localStorage
    const storedData = JSON.parse(localStorage.getItem("userData"));
    setUserData(storedData);
  }, []);

  if (!userData) {
    return <div>Loading...</div>; // Display loading while data is fetched
  }

  return (
    <div className="dashboard-container">
      <h1>Dashboard</h1>

      <Row gutter={[16, 16]} style={{ marginBottom: "16px" }}>
        <Col xs={24}>
          <AccountBalance userData={userData} />
        </Col>
      </Row>

      <Row gutter={[16, 16]} style={{ marginBottom: "16px" }}>
        <Col xs={24}>
          <AccountSummary userData={userData} />
        </Col>
      </Row>

      <Row gutter={[16, 16]} style={{ marginBottom: "16px" }}>
        <Col xs={24}>
          <CurrencyConverter userData={userData} />
        </Col>
      </Row>

      <Row gutter={[16, 16]} style={{ marginBottom: "16px" }}>
        <Col xs={24}>
          <Approvals userData={userData} />
        </Col>
      </Row>
    </div>
  );
};

export default Dashboard;
