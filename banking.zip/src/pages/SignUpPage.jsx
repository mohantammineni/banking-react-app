import React, { useState } from "react";
import { Form, Input, Button, Card, Typography, DatePicker, message } from "antd";

const { Title } = Typography;

const SignupPage = () => {
  const [loading, setLoading] = useState(false);

  const handleSignup = async (values) => {
    const payload = {
      name: values.name,
      dob: values.dob.format("YYYY-MM-DD"),
      joining_on: values.joiningOn.format("YYYY-MM-DD"),
      mobile: values.mobile,
      password: values.password,
    };

    setLoading(true);

    try {
      const response = await fetch("https://yourapiendpoint.com/signup", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(payload),
      });

      const data = await response.json();

      if (response.ok) {
        message.success("Signup successful! Redirecting...");
        // Add your redirect logic here
      } else {
        message.error(data.message || "Signup failed. Please try again.");
      }
    } catch (error) {
      console.error("An error occurred:", error);
      message.error("Unable to connect to the server. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div style={styles.container}>
      <Card style={styles.card} bordered={true}>
        <Title level={2} style={styles.title}>
          Create an Account
        </Title>
        <Form layout="vertical" onFinish={handleSignup} style={styles.form}>
          <Form.Item
            label="Name"
            name="name"
            rules={[{ required: true, message: "Please enter your name!" }]}
          >
            <Input placeholder="Enter your name" />
          </Form.Item>
          <Form.Item
            label="Date of Birth"
            name="dob"
            rules={[{ required: true, message: "Please select your date of birth!" }]}
          >
            <DatePicker style={{ width: "100%" }} placeholder="Select your date of birth" />
          </Form.Item>
          <Form.Item
            label="Joining On"
            name="joiningOn"
            rules={[{ required: true, message: "Please select your joining date!" }]}
          >
            <DatePicker style={{ width: "100%" }} placeholder="Select your joining date" />
          </Form.Item>
          <Form.Item
            label="Mobile"
            name="mobile"
            rules={[
              { required: true, message: "Please enter your mobile number!" },
              { pattern: /^\d{10}$/, message: "Mobile number must be 10 digits!" },
            ]}
          >
            <Input placeholder="Enter your mobile number" />
          </Form.Item>
          <Form.Item
            label="Password"
            name="password"
            rules={[{ required: true, message: "Please enter your password!" }]}
          >
            <Input.Password placeholder="Enter your password" />
          </Form.Item>
          <Form.Item>
            <Button
              type="primary"
              shape="round"
              htmlType="submit"
              block
              loading={loading}
            >
              Sign Up
            </Button>
          </Form.Item>
        </Form>
      </Card>
    </div>
  );
};

const styles = {
  container: {
    height: "100vh",
    display: "flex",
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: "#eff4fb",
  },
  card: {
    width: 400,
    padding: "20px",
    boxShadow: "0 4px 8px rgba(0, 0, 0, 0.1)",
    borderRadius: "8px",
    backgroundColor: "#fff",
  },
  title: {
    textAlign: "center",
    marginBottom: "20px",
  },
  form: {
    marginTop: "10px",
  },
};

export default SignupPage;
